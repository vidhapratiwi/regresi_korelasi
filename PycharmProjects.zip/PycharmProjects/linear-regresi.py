#library-library yang dibutuhkan
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import numpy as np
import matplotlib.pyplot as plt

#Vidha Rossa Pratiwi (152017023)

#data untuk variable X untuk Kolom X dan Y untuk kolom Y
#X = tahun bekerja
#Y = gaji (ribu USD/tahun)
X_train = np.array([1.1,1.3,1.5,2,2.2,2.9,3,3.2,3.2,3.7,3.9,4,4,4.1,4.5,4.9,5.1,5.3,5.9,6,6.8,7.1,7.9,8.2,8.7,9,9.5,9.6,10.3,10.5])
y_train = np.array([39,46,37,43,39,56,60,54,64,57,63,55,56,57,61,67,66,83,81,93,91,98,10,11,10,10,11,11,12,12])
X_train = X_train.reshape(-1, 1)
y_train = y_train.reshape(-1, 1)

#Create linear regression object
model_reg = LinearRegression()

#train the model using the training sets
model_reg.fit(X_train, y_train)

print('Panjang X = {}'.format(len(X_train)))
print('Panjang Y = {}'.format(len(y_train)))

#regression coefficients
print('Koefisien = {}'.format(model_reg.coef_))
print('Konstanta ={} '.format(model_reg.intercept_))

import numpy as np
import scipy.stats
import matplotlib.pyplot as plt

X = np.array([1.1,1.3,1.5,2,2.2,2.9,3,3.2,3.2,3.7,3.9,4,4,4.1,4.5,4.9,5.1,5.3,5.9,6,6.8,7.1,7.9,8.2,8.7,9,9.5,9.6,10.3,10.5])
Y = np.array([39,46,37,43,39,56,60,54,64,57,63,55,56,57,61,67,66,83,81,93,91,98,10,11,10,10,11,11,12,12])
r = np.corrcoef(X, Y)

print("r = ", r)